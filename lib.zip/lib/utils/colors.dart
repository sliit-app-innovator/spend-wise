import 'package:flutter/material.dart';

class AppColors {
  static const Color BOX_DECORATION_COLOR = Color.fromARGB(255, 100, 79, 70);
  static const Color TABLE_HEADER_COLOR = Color.fromARGB(255, 167, 141, 131);
  static const Color APP_ABR_COLOR = Color.fromARGB(255, 141, 110, 99);
}
